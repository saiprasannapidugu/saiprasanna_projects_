from flask import Flask, request, render_template, jsonify
import requests
import json
import random
from threading import Thread
import webbrowser
import time
from werkzeug.serving import make_server
from datetime import datetime, timedelta

app = Flask(__name__)

# Load destination data from JSON file
with open('destinations.json') as f:
    city_data = json.load(f)

def determine_age_group(age):
    if age < 25:
        return 'youth'
    elif 25 <= age <= 45:
        return 'family'
    else:
        return 'senior'

def determine_budget_level(budget):
    if budget < 5000:
        return 'low'
    elif budget < 15000:
        return 'medium'
    else:
        return 'high'

def get_season(start_date):
    month = start_date.month
    if month in [3, 4, 5]:
        return 'summer'
    elif month in [6, 7, 8, 9]:
        return 'monsoon'
    elif month in [10, 11]:
        return 'autumn'
    else:
        return 'winter'

def match_interests(interests, city_info):
    score = 0
    for interest in interests:
        if interest in city_info.get('interests', []):
            score += 1
    return score

@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        try:
            age = int(request.form['age'])
            budget = int(request.form['budget'])
            start_date = datetime.strptime(request.form['start_date'], '%Y-%m-%d')
            end_date = datetime.strptime(request.form['end_date'], '%Y-%m-%d')
            interests = request.form.getlist('interests')

            age_group = determine_age_group(age)
            budget_level = determine_budget_level(budget)
            season = get_season(start_date)
            duration = (end_date - start_date).days

            # Match by age, budget, and season
            matched = []
            for city, info in city_data.items():
                if (info['age_group'] == age_group and 
                    info['budget'] == budget_level and 
                    season in info.get('best_seasons', ['summer', 'winter', 'monsoon', 'autumn'])):
                    interest_score = match_interests(interests, info)
                    matched.append((city, interest_score))

            # Sort by interest match score
            matched.sort(key=lambda x: x[1], reverse=True)
            matched_cities = [city for city, _ in matched]

            # Fallbacks
            if not matched_cities:
                matched_cities = [city for city, info in city_data.items() 
                                if info['budget'] == budget_level]
            if not matched_cities:
                matched_cities = list(city_data.keys())

            selected_city = random.choice(matched_cities[:3])  # Choose from top 3 matches
            city_info = city_data[selected_city]

            # Generate itinerary based on duration
            itinerary = []
            if duration > 0:
                for i in range(duration):
                    day_plan = {
                        "day": i + 1,
                        "date": (start_date + timedelta(days=i)).strftime('%Y-%m-%d'),
                        "morning": random.choice(city_info.get('attractions_day', [])),
                        "afternoon": random.choice(city_info.get('attractions_day', [])),
                        "evening": random.choice(city_info.get('attractions_night', [])),
                        "breakfast": random.choice(city_info.get('restaurants_breakfast', [])),
                        "lunch": random.choice(city_info.get('restaurants_lunch', [])),
                        "dinner": random.choice(city_info.get('restaurants_dinner', []))
                    }
                    itinerary.append(day_plan)

            plan = {
                "city": selected_city,
                "start_date": start_date.strftime('%Y-%m-%d'),
                "end_date": end_date.strftime('%Y-%m-%d'),
                "duration": duration,
                "season": season,
                "itinerary": itinerary,
                **city_info
            }

            return render_template("result.html", age=age, budget=budget, plan=plan)

        except Exception as e:
            return render_template("index.html", error="Invalid input!")

    return render_template("index.html")

WEATHER_API_KEY = "YOUR_API_KEY"  # Replace with your OpenWeatherMap API key
WEATHER_API_URL = "http://api.openweathermap.org/data/2.5/weather"

@app.route("/weather")
def get_weather():
    city = request.args.get('city')
    if not city:
        return jsonify({"error": "City not provided"}), 400

    params = {
        "q": city,
        "appid": WEATHER_API_KEY,
        "units": "metric"
    }
    try:
        response = requests.get(WEATHER_API_URL, params=params)
        response.raise_for_status()  # Raise an exception for bad status codes
        weather_data = response.json()
        return jsonify(weather_data)
    except requests.exceptions.RequestException as e:
        return jsonify({"error": str(e)}), 500

@app.route('/get_destinations')
def get_destinations():
    try:
        with open('destinations.json', 'r') as f:
            destinations = json.load(f)
        return jsonify(destinations)
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# Auto-launch browser
class ServerThread(Thread):
    def __init__(self, app):
        Thread.__init__(self)
        self.server = make_server('localhost', 5000, app)
        self.ctx = app.app_context()
        self.ctx.push()

    def run(self):
        self.server.serve_forever()

    def shutdown(self):
        self.server.shutdown()

if __name__ == "__main__":
    server = ServerThread(app)
    server.start()
    time.sleep(1)
    webbrowser.open("http://localhost:5000")
